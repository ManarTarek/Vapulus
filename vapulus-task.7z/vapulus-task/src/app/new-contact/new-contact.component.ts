import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-new-contact',
  templateUrl: './new-contact.component.html',
  styleUrls: ['./new-contact.component.scss']
})
export class NewContactComponent implements OnInit {
  constructor(private route :Router,private formBuilder: FormBuilder) { }
  url: string;
  first_name: string;
  last_name: string;
  code: string;
  phone: string;
  email: string;
  registerForm: FormGroup;
  submitted = false;
  target: string;
  get f() { return this.registerForm.controls; }

  onSubmit() {
      this.submitted = true;

      // stop here if form is invalid
      if (this.registerForm.invalid) {
          return;
      }

  localStorage.setItem("first_name",this.first_name);
  localStorage.setItem("last_name",this.last_name);
  localStorage.setItem("phone",this.phone);
  localStorage.setItem("email",this.email);
  localStorage.setItem("image",this.url);
  this.target="success_tic";
  }
onSelectFile(event) { // called each time file input changes
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url
      reader.onload = (event:any) => {
        this.url = event.target.result
        } 
    }
}
add(){
  localStorage.setItem("first_name",this.first_name);
  localStorage.setItem("last_name",this.last_name);
  localStorage.setItem("phone",this.phone);
  localStorage.setItem("email",this.email);
  localStorage.setItem("image",this.url);
  console.log(this.first_name,this.last_name,this.email,this.phone);
 // this.route.navigate(['/']);

}
cancel(){
this.route.navigate(['/']);
}
  ngOnInit() {
    this.url="https://www.gatewaychamber.com/Content/Uploads/ProfilePictures/default-user.png";
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      phone: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
  });
  }

}
