import { SearchContactsPipe } from './search-contacts.pipe';

describe('SearchContactsPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchContactsPipe();
    expect(pipe).toBeTruthy();
  });
});
