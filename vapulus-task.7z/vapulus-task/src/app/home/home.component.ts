import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import latestContacts from "../../assets/files/recent-contact.json";
import allContacts from "../../assets/files/contacts.json";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"]
})
export class HomeComponent implements OnInit {
  recent: any;
  contacts: any[];
  first_name: string='';
  last_name: string='';
  phone: string ='';
  email: string ='';
  image:any;
  searchText: string;
  letters:string[]=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","y","z"];
  constructor(private router: Router) {
    this.recent = latestContacts.data;
    this.contacts = allContacts.data;
    console.log("latestContacts", this.recent);
  }
   add_contact() {
    this.router.navigate(['/app-new-contact']);
  }
  ngOnInit() {
    this.first_name=localStorage.getItem("first_name");
    this.last_name=localStorage.getItem("last_name");
    this.phone=localStorage.getItem("phone");
    this.email=localStorage.getItem("email");
    this.image=localStorage.getItem("image");
    console.log("letters",this.first_name);

  }
}
